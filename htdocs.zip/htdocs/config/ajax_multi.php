<?php
# TEMP!

print_r($_REQUEST);
?>
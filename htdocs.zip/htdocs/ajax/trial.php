<script type="text/javascript" src="js/jquery.wysiwyg.js"></script>
<script type="text/javascript">
$(function() {
    $('#wysiwyg').wysiwyg();
});
</script>

<textarea id="wysiwyg"></textarea>

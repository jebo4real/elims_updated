<script type="text/javascript" src="js/jquery-1.3.2.js"></script>    
<script type="text/javascript" src="js/jquery-barcode-2.0.2.js"></script>  

<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
